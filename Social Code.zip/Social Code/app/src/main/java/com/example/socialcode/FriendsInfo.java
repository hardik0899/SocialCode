package com.example.socialcode;

public class FriendsInfo {
    String name,email,profilepic;

    public FriendsInfo(String name, String email, String profilepic) {
        this.name = name;
        this.email = email;
        this.profilepic = profilepic;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getProfilepic() {
        return profilepic;
    }
}
